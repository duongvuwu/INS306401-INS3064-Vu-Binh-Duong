CREATE DATABASE IF NOT EXISTS student_management_db 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE student_management_db;

-- 2. Tạo bảng classes 
CREATE TABLE classes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    class_name VARCHAR(255) NOT NULL,
    department VARCHAR(255)
);

-- 3. Tạo bảng students 
CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_code VARCHAR(50) UNIQUE NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    age INT,
    class_id INT,
    FOREIGN KEY (class_id) REFERENCES classes(id)
);