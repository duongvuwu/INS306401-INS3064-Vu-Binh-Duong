-- Tạo Database mới cho cửa hàng
CREATE DATABASE IF NOT EXISTS shop_db
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Chỉ định sử dụng Database vừa tạo
USE shop_db;

-- Tạo bảng products với các ràng buộc khắt khe
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    sku VARCHAR(100) UNIQUE,                -- Ràng buộc UNIQUE: Mã SKU không được trùng nhau
    price DECIMAL(10,2) CHECK (price > 0),  -- Ràng buộc CHECK: Giá bán bắt buộc phải lớn hơn 0
    stock_quantity INT DEFAULT 0            -- Ràng buộc DEFAULT: Nếu không nhập số lượng, tự động gán bằng 0
);