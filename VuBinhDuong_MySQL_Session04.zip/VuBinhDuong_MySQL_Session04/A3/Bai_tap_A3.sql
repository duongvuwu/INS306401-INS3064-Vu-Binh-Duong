-- Tạo Database mới cho Blog
CREATE DATABASE IF NOT EXISTS blog_db
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Chỉ định sử dụng Database vừa tạo
USE blog_db;

-- 1. Tạo bảng users (Quản lý người dùng)
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL
);

-- 2. Tạo bảng categories (Danh mục bài viết)
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL
);

-- 3. Tạo bảng posts (Nội dung bài viết)
-- Bảng này phải tạo sau cùng vì nó chứa Khóa ngoại trỏ về 2 bảng trên
CREATE TABLE posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content LONGTEXT,                               -- Ràng buộc: Dùng LONGTEXT để chứa nội dung bài viết dài không giới hạn
    view_count INT DEFAULT 0,                       -- Ràng buộc: Mặc định lượt xem bắt đầu từ 0
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- Ràng buộc: Tự động chèn ngày giờ hiện tại lúc bài viết được tạo
    user_id INT,                                    
    category_id INT,                                
    FOREIGN KEY (user_id) REFERENCES users(id),         -- Khóa ngoại liên kết với tác giả
    FOREIGN KEY (category_id) REFERENCES categories(id) -- Khóa ngoại liên kết với danh mục
);